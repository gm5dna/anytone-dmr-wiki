@ECHO off

:INIZIO
CLS
COLOR A
echo.
echo   ************************************************
echo   *   Band Conversion    file rdt                *
echo   *                                              *
echo   *        for radio Anytone 878 /578            *
echo   *                                              *
echo   *             by IK8JHL Francesco              *
echo   *                                              *
echo   ************************************************
echo.
set FILE=new
set /P FILE=Enter name of the RDT file you wish to convert without extension: 
echo The name entered is %FILE%
choice /C:YN /M "Proceed"
IF errorlevel 2 goto INIZIO
:MODE
set BAND=0x00
echo HEX  MODE  RX Frequency    / TX Frequency 
echo 00 = 00000 400-480 136-174 / 400-480 136-174
echo 01 = 00001 400-480 136-174 / 400-480 136-174 (12.5KHz Only)
echo 02 = 00002 430-440 136-174 / 430-440 136-174
echo 03 = 00003 400-480 136-174 / 430-440 144-146
echo 04 = 00004 434-438 144-146 / 434-438 144-146
echo 05 = 00005 434-447 144-146 / 434-447 144-146
echo 06 = 00006 446-447 136-174 / 446-447 136-174
echo 07 = 00007 420-480 136-174 / 420-450 144-148
echo 08 = 00008 400-470 136-174 / 400-470 136-174
echo 09 = 00009 430-432 144-146 / 430-432 144-146
echo 0A = 00010 400-480 136-174 / 430-450 144-148
echo 0B = 00011 400-520 136-174 / 400-520 136-174
echo 0C = 00012 400-490 136-174 / 400-490 136-174
echo 0D = 00013 400-480 136-174 / 403-470 136-174
echo 0E = 00014 400-520 220-225 136-174 / 400-520 220-225 136-174
echo 0F = 00015 420-520 144-148 / 420-520 144-148
echo 10 = 00016 430-440 144-147 / 430-440 144-147
echo 11 = 00017 430-440 136-174 / 136-174
echo 12 = 00018 400-480 220-225 136-174 / 420-450 222-225 144-148
echo.
set /P BAND=Enter the desired band as indicated in the ***HEX*** (first) column:
echo The band you have chosen to convert over to is HEX %BAND%
echo.
choice /C:YN /M "Is this correct"
IF errorlevel 2 goto MODE
echo.
COLOR FC
ren %FILE%.rdt %FILE%.txt
hexalter %FILE%.txt 0x11=0x%BAND%
COLOR F1
echo.
echo.    
echo.
echo.
COLOR FC
ren %FILE%.txt %FILE%_Band_0x%BAND%.rdt
COLOR F2
echo.
echo    *-------------------------------------* 
echo    *                                     *
echo    *        Procedure finished           * 
echo    *                                     * 
echo    *-------------------------------------*
echo.
choice /C:YN /M "Do you want to convert another file"
IF errorlevel 2 goto FINE
goto INIZIO
:FINE

