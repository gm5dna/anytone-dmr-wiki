When we want to change band to our Anytone radio, (via TestMode or with AT_option) the radio will be reset, but when we try to reload our saved codeplug, the CP editor will report
"Band error!"
because it was previously saved on a different band.
While it is possible to export the old Codeplug, and import it into the radio after re-reading it, unfortunately many settings will still have to be rewritten by hand.

I then wrote this script to make the process of converting the old codeplug to the new chosen band easy.

How does it work?
1) Copy the file to be transferred in the RDT Band Conversion folder (always keep an original copy of your file safe somewhere else, as the script will overwrite the file to be converted)
2) Launch the Convert.bat file
3) You will be asked to write the name of your file without any extension (so if the file is test.rdt you will write only test)
   you will be asked for confirmation, if it is wrong, rewrite it
4) You will be asked for the number of the band you have already chosen for your radio
   for example to set band 14 on your radio, then reading the table enter the value in hexadecimal 0E.
   The value to convert to MUST be entered as HEX (the values given in the first column)
   you will be asked for confirmation here too, if everything is ok
5) If everything is successful, 'Procedure finished' will be displayed and your converted rdt will be renamed to (in our example) "test_Band_0x0e.rdt" which will be your new converted file for band 14

by IK8JHL Francesco